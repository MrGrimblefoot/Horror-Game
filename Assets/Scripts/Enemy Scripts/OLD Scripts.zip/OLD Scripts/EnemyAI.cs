using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;
using System;
using Random = UnityEngine.Random;

public class EnemyAI : MonoBehaviour
{
    [Header("Variables")]
    [SerializeField] private NavMeshAgent navMeshAgent;
    //[SerializeField] private Rigidbody rb;
    [SerializeField] private Animator anim;
    //[SerializeField] Transform player;
    [SerializeField] private AISensor farSensor;
    [SerializeField] private AISensor closeSensor;
    [SerializeField] private AISensor attackSensor;
    //[SerializeField] private float walkSpeed;
    //[SerializeField] private float runSpeed;
    //[SerializeField] private float rotationSpeed;
    [SerializeField] private float currentAnimSpeed;
    [SerializeField] private Transform currentTarget;
 
    [Header("Patrol")]
    [SerializeField] private float wanderRange;
    [SerializeField] private float delayStart;
    [SerializeField] private float delayTime;
    [SerializeField] LayerMask whatIsGround;
    Vector3 point;

    [Header("Invesigate")]
    [SerializeField] private float suspicion;
    [SerializeField] private float suspicionMultiplier;
    [SerializeField] private float maxSuspicion;
    [SerializeField] private int timesHasSeenPlayer;

    [Header("Attacking")]
    [SerializeField] private float timeBetweenAttacks;
    [SerializeField] private int ammountOfAttacks;
    bool alreadyAttacked;

    [Header("Debug")]
    [Range(1, 4)]
    [Tooltip("1, Wander State. 2, Investigate State. 3, Chase State. 4, Attack State.")]
    [SerializeField] private float state;
    [SerializeField] private GameObject walkPointDebug;
    [SerializeField] private bool canWalk;
    [SerializeField] private bool hasMadePoint;

    void Awake()
    {
        navMeshAgent = GetComponent<NavMeshAgent>();
        //rb = GetComponent<Rigidbody>();
        canWalk = true;
        anim = GetComponent<Animator>();
        AnimationSpeedTransition(0f);

        Invoke("CheckIfOnNavmesh", 2f);

        state = 1;
    }

    private void CheckIfOnNavmesh() { if (!navMeshAgent.isOnNavMesh) Destroy(gameObject); }

    void Update()
    {
        HandleStateSwitch();
        AnimationSpeedTransition(currentAnimSpeed);
    }

    private void HandleStateSwitch()
    {
        switch (state)
        {
            case 1:
                Patroling();
                break;            
            case 2:
                Investigate();
                break;            
            case 3:
                Chase();
                break;            
            case 4:
                Attack();
                break;
        }
    }

    //State 1
    private void Patroling()
    {
        if(!farSensor.canDetectPlayer && !closeSensor.canDetectPlayer)
        {
            if (navMeshAgent.enabled && navMeshAgent.remainingDistance <= navMeshAgent.stoppingDistance) //done with path
            {
                currentAnimSpeed = 0f;
                if (!hasMadePoint)
                {
                    if (RandomPoint(transform.position, wanderRange, out point)) //pass in our centre point and radius of area
                    {
                        hasMadePoint = true;
                        canWalk = true;
                    }
                }

                if (canWalk)
                {
                    delayTime += Time.deltaTime/* * 3*/;
                    if (delayTime >= delayStart)
                    {
                        delayTime = 0;

                        Debug.DrawRay(point, Vector3.up, Color.yellow, 1.0f); //so you can see with gizmos
                        currentAnimSpeed = 0.5f;
                        navMeshAgent.SetDestination(point);
                        //navMeshAgent.speed = walkSpeed;
                        hasMadePoint = false;
                        //HandleRotateTowardsTarget();
                    }
                }
            }
        }
        else { state = 2; hasMadePoint = false; }
    }

    bool RandomPoint(Vector3 center, float range, out Vector3 result)
    {
        Vector3 randomPoint = center + Random.insideUnitSphere * range; //random point in a sphere 
        NavMeshHit hit;
        if (NavMesh.SamplePosition(randomPoint, out hit, 1.0f, NavMesh.AllAreas)) //documentation: https://docs.unity3d.com/ScriptReference/AI.NavMesh.SamplePosition.html
        {
            //the 1.0f is the max distance from the random point to a point on the navmesh, might want to increase if range is big
            //or add a for loop like in the documentation
            result = hit.position;
            return true;
        }

        result = Vector3.zero;
        canWalk = false;
        return false;
    }

    //State 2
    private void Investigate()
    {
        if(farSensor.Objects.Count > 0)
        {
            currentAnimSpeed = 0f;
            suspicion += Time.deltaTime * suspicionMultiplier;
            if(suspicion >= maxSuspicion) { currentTarget = farSensor.Objects[0].gameObject.transform; state = 3; }
        }
        else
        {
            currentAnimSpeed = 0f;
            if (suspicion > 0) { suspicion -= Time.deltaTime / suspicionMultiplier; }
            if(suspicion <= 0) { suspicion = 0; delayTime = delayStart; currentTarget = null; state = 1; }
        }
    }

    //State 3
    private void Chase()
    {
        if (farSensor.Objects.Count > 0 && farSensor.canDetectPlayer && !attackSensor.canDetectPlayer && navMeshAgent.enabled)
        {
            currentAnimSpeed = 1f;
            //navMeshAgent.speed = runSpeed;
            navMeshAgent.SetDestination(farSensor.Objects[0].transform.position);
        }
        if (farSensor.canDetectPlayer && attackSensor.canDetectPlayer) {  state = 4; }
        if(farSensor.Objects.Count == 0 && navMeshAgent.enabled) { navMeshAgent.SetDestination(transform.position); state = 2; }
    }

    //State 4
    private void Attack()
    {
        if (closeSensor.canDetectPlayer && attackSensor.canDetectPlayer)
        {
            if (!alreadyAttacked)
            {
                navMeshAgent.enabled = false;
                HandleAttack();

                alreadyAttacked = true;
                Invoke("ResetAttack", timeBetweenAttacks);
            }
        }
        if(!attackSensor.canDetectPlayer) { navMeshAgent.enabled = true; state = 3; }
        //anim.SetFloat("Speed", 0);
    }

    private void HandleAttack()
    {
        int newAttack = Random.Range(1, ammountOfAttacks);
        anim.SetInteger("Attack Number", newAttack);
    }

    private void ResetAttack()
    {
        alreadyAttacked = false;
        anim.SetInteger("Attack Number", 0);
    }

    private void AnimationSpeedTransition(float speed)
    {
        anim.SetFloat("Speed", speed);
    }

    //private void HandleRotateTowardsTarget()
    //{
    //    //Rotate with pathfinding (navmesh)
    //    Debug.Log("NavMesh Rotating Me!");
    //    Vector3 relativeDirection = transform.InverseTransformDirection(navMeshAgent.desiredVelocity);
    //    //Vector3 targetVelocity = rb.velocity;

    //    navMeshAgent.enabled = true;
    //    if (currentTarget != null) { navMeshAgent.SetDestination(currentTarget.transform.position); }
    //    //rb.velocity = targetVelocity;
    //    transform.rotation = Quaternion.Slerp(transform.rotation, navMeshAgent.transform.rotation, rotationSpeed / Time.deltaTime);
    //}
}
