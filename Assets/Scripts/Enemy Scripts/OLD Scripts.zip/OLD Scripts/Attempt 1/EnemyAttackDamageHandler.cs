using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyAttackDamageHandler : MonoBehaviour
{
    Collider damageCollider;
    public bool hasDamaged;
    [SerializeField] private EnemyAttackAction attack;

    private void Awake()
    {
        damageCollider = GetComponent<Collider>();
        damageCollider.isTrigger = true;
        damageCollider.enabled = false;
        //hasDamaged = false;
    }

    private void OnTriggerEnter(Collider collision)
    {
        Debug.Log(collision.name);
        if (collision.tag == "Player" || collision.tag == "LocalPlayer")
        {
            Debug.Log("The collision is a player.");
            PlayerPolishManager player = collision.GetComponent<PlayerPolishManager>();
            if (player != null/* && !hasDamaged*/)
            {
                Debug.Log("Player is not null.");
                player.ApplyDamage(attack.damage);
                //hasDamaged = true;
            }
        }
    }
}
