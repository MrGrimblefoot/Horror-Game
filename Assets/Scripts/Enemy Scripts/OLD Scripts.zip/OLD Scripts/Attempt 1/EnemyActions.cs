using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyActions : ScriptableObject
{
    public string actionAnimation;
}
